import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Constructor extends PApplet {

final float versionNumber=2;

PFont fontNormal;
PFont fontBold;
//PFont fontItalic;
//PFont fontUnderlined;

public void setup() {
  
  //key=' ';
  fontNormal=loadFont("Monospaced-10-normal.vlw");
  fontBold=loadFont("Monospaced-15-normal.vlw");
  //fontItalic=loadFont("Monospaced-10-italic.vlw");
  //fontUnderlined=loadFont("Monospaced-10-underlined.vlw");
  textFont(fontNormal);
}
class Edge {
  Point a, b;
  float dist;
  //float d;
  float origDist;
  boolean isMuscle;
  float period;
  float amp;
  float off;
  int muscleType;
  Edge(Point p1, Point p2, float d) {
    p1.isInEdge=true;
    p2.isInEdge=true;
    a=p1;
    b=p2;
    isMuscle=false;
    //isMuscle=random(1)<0.25;
    //period=0.1;
    //amp=d;
    //off=0;
    origDist=d;
    //this.d=d;
    dist=d;
  }

  public void constrainLength() {
    float ka=unfixedK;
    float kb=ka;
    //dist=3*d*(abs(cos(frameCount*0.01))+0.1);
    if(isMuscle){
      float val=0;
      if(muscleType==muscleJerkyCos){
        val=abs(cos(frameCount*period+off))+0.1f;
        ka=kb=jerkyCosK;
      }
      else if(muscleType==muscleSmoothCos){
        val=(cos(frameCount*period+off)+1.5f)/2.5f;
        ka=kb=smoothCosK;
      }
      dist=amp*val;
    }
    if (a.fixed)kb=fixedK;
    if (b.fixed)ka=fixedK;

    PVector delta=PVector.sub(a.pos, b.pos);
    float deltaLength=delta.mag();
    if (abs(deltaLength)<1)return;
    float d=(deltaLength-dist)/deltaLength;
    if (!a.fixed) {
      a.pos.x-=delta.x*ka*d/2;
      a.pos.y-=delta.y*ka*d/2;
      a.update();
    }
    if (!b.fixed) {
      b.pos.x+=delta.x*kb*d/2;
      b.pos.y+=delta.y*kb*d/2;
      b.update();
    }
  }
  public void display() {
    a.display();
    b.display();
    //stroke(0);
    if(isMuscle){
      if(muscleType==muscleJerkyCos)stroke(colMuscleJerkyCos);
      else if(muscleType==muscleSmoothCos)stroke(colMuscleSmoothCos);
    }else{
      stroke(colEdge);
    }
    line(a.pos.x, a.pos.y, b.pos.x, b.pos.y);
  }
}
class Point {
  PVector pos, vel, acc;
  boolean fixed=false;
  boolean isInEdge=false;
  Point(float x, float y) {
    pos=new PVector(x, y);
    vel=new PVector(0, 0);
    acc=new PVector(0, 0);
  }
  public void display() {
    if (fixed) {
      stroke(colFixedPoint);
      fill(colFixedPoint);
    } else {
      stroke(200);
      fill(200);
    }
    ellipse(pos.x, pos.y, 10, 10);
  }
  public void update() {
    if (pos.y<height-margin) {
      //GRAVITY
      acc.y=gravity;
    } else {
      acc.y=0;
    }
    if (pos.y>height-margin) {
      vel.y=-abs(min(bounceForce, vel.y));
      pos.y=height-margin;
    }
    vel=vel.add(acc);
    pos=pos.add(vel);
  }
}
public void draw() {
  background(255);
  line(margin, height-margin, width-margin, height-margin);
  for (Edge e : edges) {
    if (isSim)e.constrainLength();
  }
  for (Edge e : edges) {
    e.display();
  }
  for (Point p : points) {
    if (p.isInEdge)continue;
    p.display();
  }
  if (p1!=null) {
    fill(255, 0, 0);
    stroke(255, 0, 0);
    ellipse(p1.pos.x, p1.pos.y, 40, 40);
  }
  Point p=intersection();
  if (p!=null) {
    fill(0, 0, 255, 100);
    stroke(0, 0, 255, 100);
    ellipse(p.pos.x, p.pos.y, 40, 40);
  }

  displayControls();
}

public void saveFileSelected(File file) {
  if (file==null)return;
  println(file);
  curOpened=file.getAbsolutePath();
  saveJSONObject(toJSON(), file.getAbsolutePath()  );
}
public void openFileSelected(File file) {
  if (file==null)return;
  println(file);
  curOpened=file.getAbsolutePath();
  fromJSON(loadJSONObject(file.getAbsolutePath()));
}
public void fromJSON(JSONObject obj) {
  fixedK=obj.getFloat("fixedK");
  unfixedK=obj.getFloat("unfixedK");
  gravity=obj.getFloat("gravity");
  margin=obj.getFloat("margin");
  jerkyCosK=obj.getFloat("jerkyCosK");
  smoothCosK=obj.getFloat("smoothCosK");
  JSONArray pointsArr=obj.getJSONArray("pointsArr");
  points=new ArrayList<Point>();
  println("Loading points");
  for (int i=0; i<pointsArr.size(); i++) {
    print(i);
    JSONObject pointObj=pointsArr.getJSONObject(i);
    Point p=new Point(pointObj.getFloat("posx"), pointObj.getFloat("posy"));
    p.vel=new PVector(pointObj.getFloat("velx"), pointObj.getFloat("vely"));
    p.acc=new PVector(pointObj.getFloat("accx"), pointObj.getFloat("accy"));
    p.fixed=pointObj.getBoolean("fixed");
    p.isInEdge=pointObj.getBoolean("isInEdge");
    points.add(p);
  }
  println("\nLoading edges");
  JSONArray edgesArr=obj.getJSONArray("edgesArr");
  edges=new ArrayList<Edge>();
  for (int i=0; i<edgesArr.size(); i++) {
    print(i);
    JSONObject edgeObj=edgesArr.getJSONObject(i);
    Edge e=new Edge(points.get(edgeObj.getInt("a")), points.get(edgeObj.getInt("b")), edgeObj.getFloat("dist"));
    e.isMuscle=edgeObj.getBoolean("isMuscle");
    if(e.isMuscle){
      e.muscleType=edgeObj.getInt("type");
      e.amp=edgeObj.getFloat("amp");
      e.period=edgeObj.getFloat("period");
      e.off=edgeObj.getFloat("off");
    }
    edges.add(e);
  }
  println();
}
public void keyPressed() {
  if (key==' ')isSim=!isSim;
  else if (key=='s') {
    isSim=false;
    selectOutput("Save construction", "saveFileSelected", new File("~/Documents/MyConstructor/Untitled.constr"+versionNumber));
  } else if (key=='o') {
    isSim=false;
    selectInput("Open construction", "openFileSelected", new File("~/Documents/MyConstructor/"));
  } else if (key=='d') {
    Point i=intersection();
    if (i==null)return;
    removeEdgesWithPoint(i);
    points.remove(i);
  }
}
public void mousePressed() {
  if (key=='p')points.add(new Point(mouseX, mouseY));
  else if (key=='f') {
    Point i=intersection();
    if (i!=null)i.fixed=!i.fixed;
  } else if (key=='e'||key=='m'||key==',') {
    isEdgeModeMuscle=key=='m'||key==',';
    Point i=intersection();
    if (i==null)return;
    if (p1==null)p1=i;
    else if (p2==null) {
      p2=i;
      Edge edge=new Edge(p1,p2,100);
      edge.isMuscle=false;
      edge.muscleType=-1;
      if(isEdgeModeMuscle){
        edge.isMuscle=true;
        edge.period=0.1f;
        edge.amp=100;
        edge.off=0;
        if(key=='m')edge.muscleType=muscleJerkyCos;
        else if(key==',')edge.muscleType=muscleSmoothCos;
      }
      edges.add(edge);
      p1=p2=null;
    }
  }
}
public JSONObject toJSON() {
  JSONObject obj=new JSONObject();
  obj.setFloat("fixedK", fixedK);
  obj.setFloat("unfixedK", unfixedK);
  obj.setFloat("gravity",gravity);
  obj.setFloat("margin",margin);
  obj.setFloat("jerkyCosK",jerkyCosK);
  obj.setFloat("smoothCosK",smoothCosK);
  JSONArray pointsArr=new JSONArray();
  JSONArray edgesArr=new JSONArray();

  for (Point p : points) {
    JSONObject pointObj=new JSONObject();
    pointObj.setFloat("posx", p.pos.x);
    pointObj.setFloat("posy", p.pos.y);
    pointObj.setFloat("velx", p.vel.x);
    pointObj.setFloat("vely", p.vel.y);
    pointObj.setFloat("accx", p.acc.x);
    pointObj.setFloat("accy", p.acc.y);
    pointObj.setBoolean("fixed", p.fixed);
    pointObj.setBoolean("isInEdge", p.isInEdge);
    pointsArr.append(pointObj);
  }
  for (Edge e : edges) {
    JSONObject edgeObj=new JSONObject();
    edgeObj.setFloat("dist", e.dist);
    edgeObj.setBoolean("isMuscle",e.isMuscle);
    if(e.isMuscle){
      edgeObj.setFloat("amp",e.amp);
      edgeObj.setFloat("period",e.period);
      edgeObj.setFloat("off",e.off);
    }
    edgeObj.setInt("a", points.indexOf(e.a));
    edgeObj.setInt("b", points.indexOf(e.b));
    edgeObj.setInt("type",e.muscleType);
    edgesArr.append(edgeObj);
  }

  obj.setJSONArray("pointsArr", pointsArr);
  obj.setJSONArray("edgesArr", edgesArr);
  return obj;
}

public Point randPoint() {
  return points.get((int)random(points.size()));
}
boolean isEdgeModeMuscle=false;
public Point intersection() {
  for (Point p : points)if (PVector.dist(new PVector(mouseX, mouseY), p.pos)<20)return p;
  return null;
}
public void removeEdgesWithPoint(Point p) {
  for (int i=0; i<edges.size(); i++) {
    Edge e=edges.get(i);
    if (e.a==p||e.b==p) {
      edges.remove(i);
      if (e.a!=p)e.a.isInEdge=false;
      if (e.b!=p)e.b.isInEdge=false;
      removeEdgesWithPoint(p);
    }
  }
}
public String getMode(){
  if(key==' ')return "pause/unpause simulation";
  if(key=='s')return "save construction";
  if(key=='o')return "open construction";
  if(key=='d')return "delete point";
  if(key=='p')return "place point";
  if(key=='f')return "toggle fixed point mode";
  if(key=='e')return "make an edge";
  if(key=='m')return "make jerky muscle edge";
  if(key==',')return "make smooth muscle edge";
  return "none";
}
public void displayControls(){
  textAlign(LEFT, TOP);
  fill(0);
  stroke(0);
  textSize(10);
  float diff=15;
  //text("Constructor V"+versionNumber+"\n' ' - pause/unpause simulation\n's' - save construction\n'o' - open construction\n'd' - delete point\n'p' - place point\n'f' - toggle fixed mode\n'e' - make edge\n'm' - make jerky muscle edge\n',' - make smooth muscle edge", 2, 2);
  fill(colTitle);
  stroke(colTitle);
  textFont(fontBold);
  text("Constructor V"+versionNumber,2,2);
  fill(0);
  stroke(0);
  textFont(fontNormal);
  text("' ' - pause/unpause simulation",2,2+diff*1);
  text("'s' - save construction",2,2+diff*2);
  text("'o' - open construction",2,2+diff*3);
  text("'d' - delete point",2,2+diff*4);
  text("'p' - place point",2,2+diff*5);
  fill(colFixedPoint);
  stroke(colFixedPoint);
  text("'f' - toggle fixed point mode",2,2+diff*6);
  fill(0);
  stroke(0);
  text("'e' - make an edge",2,2+diff*7);
  fill(colMuscleJerkyCos);
  stroke(colMuscleJerkyCos);
  text("'m' - make jerky muscle edge",2,2+diff*8);
  fill(colMuscleSmoothCos);
  stroke(colMuscleSmoothCos);
  text("',' - make smooth muscle edge",2,2+diff*9);
  fill(0);
  stroke(0);
  text("'"+key+"' - "+getMode(),2,2+diff*11);
  textAlign(LEFT,BOTTOM);
  text("Currently opened file: "+curOpened,0,height);
}

String curOpened="Untitled.constr"+versionNumber;

ArrayList<Point>points=new ArrayList<Point>();
ArrayList<Edge>edges=new ArrayList<Edge>();

Point p1=null;
Point p2=null;
boolean isSim=false;
float fixedK=2;
float unfixedK=0.25f;
float jerkyCosK=1;
float smoothCosK=1;

float gravity=0.01f;
int muscleJerkyCos=0;
int muscleSmoothCos=1;

float bounce=1;
float margin=50;
float bounceForce=2;

int colMuscleJerkyCos=color(255,0,0);
int colMuscleSmoothCos=color(50,200,50);
int colEdge=color(0);
int colFixedPoint=color(200,50,50);
int colTitle=color(50,50,200);
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Constructor" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
